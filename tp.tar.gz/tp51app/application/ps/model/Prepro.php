<?php

namespace app\ps\model;

use think\Model;

class Prepro extends Model
{
    protected $table = 'ps_prepro_zy';
}
