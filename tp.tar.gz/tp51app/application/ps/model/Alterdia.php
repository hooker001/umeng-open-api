<?php

namespace app\ps\model;

use think\Model;

class Alterdia extends Model
{
    protected $table = 'ps_alter_dia_zy';
}
